package com.example.proyectoconectardb.model

data class Frase(
    val nombre:String,
    val edad: Int,
    val imagen: String,
    val correo: String,
    val frase_texto: String
)
