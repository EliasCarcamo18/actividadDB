package com.example.proyectoconectardb.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyectoconectardb.model.Frase
import com.example.proyectoconectardb.repository.FrasesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class FrasesViewModel : ViewModel() {
    private val repository = FrasesRepository()
    private val _frases = MutableStateFlow<List<Frase>>(emptyList())
    val frases: StateFlow<List<Frase>> = _frases

    init {
        obtenerFrases()
    }

    private fun obtenerFrases() {
        viewModelScope.launch {
            _frases.value = repository.obtenerFrases()
        }
    }
}