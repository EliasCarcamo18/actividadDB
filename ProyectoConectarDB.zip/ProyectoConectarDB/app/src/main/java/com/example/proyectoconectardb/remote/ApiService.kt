package com.example.proyectoconectardb.remote

import com.example.proyectoconectardb.model.Frase
import retrofit2.http.GET

interface ApiService {
    @GET("actividaddb")
    suspend fun obtenerFrases(): List<Frase>
}