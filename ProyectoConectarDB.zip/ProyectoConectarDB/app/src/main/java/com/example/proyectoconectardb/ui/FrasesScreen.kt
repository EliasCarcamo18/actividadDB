package com.example.proyectoconectardb.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.proyectoconectardb.viewmodel.FrasesViewModel



@Composable
fun FrasesScreen(viewModel: FrasesViewModel = FrasesViewModel()) {
    val frases by viewModel.frases.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center, // Centra verticalmente en la pantalla
        horizontalAlignment = Alignment.CenterHorizontally // Centra horizontalmente si es necesario
    ) {
        Text("Lista de Usuarios", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))

        frases.forEach { frase ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar a la izquierda
                    val drawableId = context.resources.getIdentifier(
                        frase.imagen, "drawable", context.packageName
                    )
                    if (drawableId != 0) {
                        Image(
                            painter = painterResource(id = drawableId),
                            contentDescription = "Avatar de ${frase.imagen}",
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Información del usuario
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = frase.nombre,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "\"${frase.frase_texto}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Correo: ${frase.correo}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}
