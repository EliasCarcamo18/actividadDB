package com.example.proyectoconectardb.repository

import com.example.proyectoconectardb.model.Frase
import com.example.proyectoconectardb.remote.RetrofitInstance

class FrasesRepository{

    suspend fun obtenerFrases(): List<Frase> {
        return RetrofitInstance.api.obtenerFrases()
    }

}